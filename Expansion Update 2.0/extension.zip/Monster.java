interface Monster {
  /** Interface method which is used for launching attacks on enemy */
  void strike(Character name);
}
